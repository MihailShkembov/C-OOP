﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _0._3Raiding.Common
{
   public static class Messages
    {
        public const string HealersMessage = "{0} - {1} healed for {2}";
        public const string AttackersMessage = "{0} - {1} hit for {2} damage";
        public const string InvalidHeroExceptionMessage = "Invalid hero!";
    }
}
