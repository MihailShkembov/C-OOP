﻿

namespace _0._3Raiding.Core.Interfaces
{
   public interface IEnginge
    {
        void Run();
    }
}
