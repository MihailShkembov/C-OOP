﻿using _0._3Raiding.Core;
using System;

namespace _0._3Raiding
{
   public class StartUp
    {
        static void Main(string[] args)
        {
            var engine = new Enginge();
            engine.Run();
        }
    }
}
