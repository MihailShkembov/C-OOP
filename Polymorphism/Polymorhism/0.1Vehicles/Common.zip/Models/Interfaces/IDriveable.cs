﻿

namespace _0._1Vehicles.Models.Interfaces
{
   public interface IDriveable
    {
        string Drive(double distance);
    }
}
