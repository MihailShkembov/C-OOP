﻿
namespace _0._1Vehicles.Models.Interfaces
{
   public interface IRefuelable
    {
        void Refuel(double liters);
    }
}
