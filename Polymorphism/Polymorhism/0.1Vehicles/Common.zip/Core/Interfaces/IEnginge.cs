﻿

namespace _0._1Vehicles.Core.Interfaces
{
   public interface IEnginge
    {
        void Run();
    }
}
