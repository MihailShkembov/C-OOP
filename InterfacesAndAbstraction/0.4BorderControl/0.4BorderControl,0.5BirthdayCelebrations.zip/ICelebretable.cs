﻿

namespace _0._4BorderControl
{
   public interface ICelebretable
    {
        public string Birthdate { get; set; }
    }
}
