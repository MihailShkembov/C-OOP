﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _0._4BorderControl
{
  public interface INamable
    {
        public string Name { get; set; }
    }
}
