﻿

namespace _0._4BorderControl
{
   public interface IIdentifiable
    {
        public string Id { get; set; }
    }
}
