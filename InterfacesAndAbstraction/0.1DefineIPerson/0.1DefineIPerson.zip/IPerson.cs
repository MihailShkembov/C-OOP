﻿namespace PersonInfo
{
   public interface IPerson
    {
        public int Age { get; set; }
        public string Name { get; set; }
    }
}
